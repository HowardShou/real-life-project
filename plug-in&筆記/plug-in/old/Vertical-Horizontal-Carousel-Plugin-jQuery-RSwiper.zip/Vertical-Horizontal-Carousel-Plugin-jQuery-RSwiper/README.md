# RSwiper
A jquery banner swipper which can run on IE7/8/9/10

## demo 
html:  
```
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8"> 
        <title>RSwiper Demo</title>
        <script src="./jquery-1.9.1.min.js"></script>
        <script src="./RSwiper.js"></script>
    </head>
    <body>
        <div style="width:100%;height:100%;background:red;position:absolute;" id="banner">
            <ul>
                <li><img src="./images/1.jpg"/></li>
                <li><img src="./images/2.jpg"/></li>
                <li><img src="./images/3.jpg"/></li>
                <li><img src="./images/4.jpg"/></li>
                <li><h1>hello world</h1></li>
            </ul>
        </div>
        <script>
           $('#banner').RSwiper({
                direction:'horizontal', //'horizontal' or 'vertical' default : 'horizontal',
                speed:3000, //duration of move to next page, millisecond (ms),default : 3000ms.
                isPagination:true, //show the pagination or not.
                isArrows:true,//show the arrow controller or not,
                tickfunc:function(curnum){
                    console.log(curnum)
                } //after the banner move to next page,this function will work
            }); 
        </script>
    </body>
</html>
```
https://pimaweichai.github.io/RSwiper/demo/
